<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

    <section id="main-bg" class="watch-video padding-100 potition-relative" style="background: url(assets/img/bg.png);">
        <div class="container video px-md-3">
            <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
            <div class="section-title text-white" data-aos="fade-zoom-in">
                <div class="space-100"></div>
                <!-- <span class="badge badge-light mb-2">Visi Kita</span> -->
                <h3 class="text-white">
                    Membangun Pembiasaan Kecil <br>
                    Memberi Dampak Positif di<br>
                    Generasi Selanjutnya 
                </h3>
                <div class="space-25"></div>
                <p><b>Techanic</b> berkomitmen memberikan solusi dan kontribusi <br>
                    terhadap isu krisis sampah elektronik
                </p>
                <p class="mt-md-3">Mari ambil bagian dalam proses pemulihan & pembaruan.</p>
            </div>
        </div>
        <img id="slider-right" src="assets/img/right-slider-0.png" class="img-fluid" style="width: 650px;height: 100%;object-fit: cover;position: absolute;right: 0;top: 0;">
        <a class="text-white" data-toggle="modal" data-target="#showBlog" href="#">CARI TAU APA YANG TERJADI PADA BUMI KITA ? <img src="assets/img/right.png" class="img-fluid small-icon ml-2"></a>
    </section>

    <div class="space-50"></div>
    <section id="cara-kerja" class="boxes padding-100">
        <div class="container">
            <div class="text-center section-title">
                <h3 class="mb-3">Bersama Techanic <br> 
                    Membangun Solusi Jangka Panjang</h3>
                <img src="assets/img/icon-r3.png" class="img-fluid" alt="">
            </div>
            <div class="space-50"></div>
            <div class="row">
                <div class="col-md-2 col-12"> </div>
                <div class="col-md-4 col-12">
                    <div class="box active" data-aos="fade-up">
                        <h5>01</h5>
                        <div class="space-20"></div>
                        <img src="assets/img/ilustrasi-edukasi.png" class="img-fluid width-img-md" alt="">
                        <div class="space-20"></div>
                        <h3>Edukasi Pentingnya Sustainability</h3>
                        <p>
                            Gunakan perangkat dan perbaiki hingga batas masa pakai yang dianjurkan. <br><br>Jika perangkat tidak dapat digunakan lagi, <br><br> ikuti program dan inisiatif pengelolaan sampah elektronik secara bertanggung jawab
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="box" data-aos="fade-up">
                        <h5>02</h5>
                        <div class="space-20"></div>
                        <img src="assets/img/my-techanic-ilustration.png" class="img-fluid width-img-md" alt="">
                        <div class="space-20"></div>
                        <h3>Platform MyTechanic Mendukung Sustainability</h3>
                        <p>
                            Aplikasi ini memudahkan customer dalam menemukan <b>tempat service terpercaya.</b>  <br><br> Histori transaksi tersimpan secara digital untuk kebutuhan klaim garansi, diharapkan pengguna bisa menggunakan perangkat dengan durasi panjang 
                        </p>
                    </div>
                </div>
                <div class="col-md-2 col-12"> </div>
                <div class="col-md-2 col-12"> </div>
                <div class="col-md-4 col-12">
                    <div class="box" data-aos="fade-up">
                        <h5>03</h5>
                        <div class="space-20"></div>
                        <img src="assets/img/ilustrasi-traking-order.png" class="img-fluid width-img-md" alt="">
                        <div class="space-20"></div>
                        <h3>Meningkatkan Kualitas Industri Reparasi</h3>
                        <p>
                            Platform <b>Techanic Business</b> membantu teknisi dan pemilik usaha reparasi dalam pembiasaan melayani secara efesien dan profesional. <br> <br> Diharapkan kepercayaan meningkat dimata customer membuat usaha terus berkembang sesuai target
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="box" data-aos="fade-up">
                        <h5>04</h5>
                        <div class="space-20"></div>
                        <img src="assets/img/ilustrasi-win.png" class="img-fluid width-img-md" alt="">
                        <div class="space-20"></div>
                        <h3>Yess, Kita Berhasil !</h3>
                        <p>
                            Membangun solusi jangka panjang yang berkelanjutan untuk mengatasi <br><b>masalah limbah elektronik</b> <br> dalam upaya menjaga lingkungan, <br><br> serta memajukan usaha kecil dan menengah di bidang reparasi.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 col-12"> </div>
            </div>
        </div>
    </section>
    
    <section id="manfaat-mytechanic" class="padding-100 background-fullwidth background-fixed bg-blue" >
        <div class="container">
            <div class="row mx-0">
                <div class="col-md-5 aos-init aos-animate" data-aos="fade-up">
                    <div class="section-title stiky-left mb-3">
                        <span class="badge badge-light">Produk Techanic</span>
                        <h3 class="text-white mt-3">
                            Ekosistem Perbaikan Masa Kini, Transaksi Berjalan Lebih Mudah & Efisien
                        </h3>
                    </div>
                </div>
                <div class="col-md-7 section-title aos-init aos-animate" data-aos="fade-zoom-in">
                    <div class="mx-0 row produk-info bg-white mb-4">
                        <div class="col-md-6">
                            <div class="d-flex align-items-start flex-column h-card mytechanic">
                                <div class="mb-auto">
                                    <img src="assets/img/my-techanic-logo-blue.png" class="logo img-fluid mt-3" alt="">
                                    <p class="font-weight-normal mt-md-2">
                                        MyTechanic sebuah marketplace platform jasa service reparasi bertujuan
                                        memudahkan pencarian tempat reparasi dan dilengkapi juga  <br><b>fitur tracking order</b>, hingga menyimpan histori transaksi untuk keperluan <br> <b>klaim garansi</b>
                                    </p>
                                </div>
                                <a href="<?= site_url().'product?title=my-techanic' ?>" class="btn btn-primary mytechanic">
                                    Pelajari Lebih Lanjut <i class="fa fa-chevron-circle-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <img src="assets/img/my-techanic-home.png" class="right img-fluid" alt="">
                        </div>
                    </div>
                    <div class="mx-0 row produk-info bg-white">
                        <div class="col-md-6">
                            <div class="d-flex align-items-start flex-column h-card">
                                <div class="mb-auto">
                                    <img src="assets/img/techanic-business-logo-blue.png" class="logo techanic-business img-fluid mt-3" alt="">
                                    <p class="font-weight-normal">
                                        Aplikasi manajemen usaha reparasi berbasis mobile, pemilik usaha dan teknisi dapat mengelola pekerjaan lebih efisien dan teratur. <br><br> Dilengkapi fitur pemantauan progress berfungsi memastikan pekerjaan selesai tepat waktu dan sesuai dengan harapan pelanggan
                                    </p>
                                </div>
                                <a href="<?= site_url().'product?title=techanic-business' ?>" class="btn btn-primary techanicbusiness">
                                    Pelajari Lebih Lanjut <i class="fa fa-chevron-circle-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <img src="assets/img/techanic-business-home.png" class="right img-fluid" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="space-100 d-none-mobile"></div>

    <?php $this->load->view('_modal_blog'); ?>