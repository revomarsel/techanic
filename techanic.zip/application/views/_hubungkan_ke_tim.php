<div class="space-50"></div>
<div class="potition-relative padding-150">
    <div class="row mx-0">
        <div class="col-md-6">
            <img src="assets/img/tim-techanic.png" class="img-fluid img-tim" alt="">
        </div>
        <div class="text-left col-md-6 section-title hubungkan-tim-right" data-aos-delay="200" data-aos="fade-zoom-in">
            <h3>
                <?= $text ?>
            </h3>
            <div class="space-25"></div>
            <a href="<?= wa_link() ?>" class="btn btn-primary font-weight-700">Hubungkan Ke Tim</a>
        </div>
    </div>
</div>
<div class="space-50"></div>