<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<section id="about" class="why-us padding-100 background-fullwidth h-bg"
        style="background-image: url(assets/img/bg-faq.png);height: 700px;align-items: center;display: flex;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center" data-aos="fade-zoom-in" data-aos-delay="200">
                    <h3 class="text-white">Cari Tau Apa Yang Menjadi <br> Kesulitan Anda</h3>
                    <div class="space-50"></div>
                    <form class="subscribe-form row m-0">
                        <div class="col-lg-5 col-md-8 col-10 offset-md-3 pl-0 text-left">
                            <div class="form-group mb-3">
                                <input type="text" class="form-control form-faq" placeholder="Ketik disini">
                            </div>
                            <div class="d-flex">
                                <a href="#" class="btn w-auto font-size-12 btn-mytechanic">
                                    <img src="assets/img/my-techanic-logo-white.png" class="white img-fluid" alt="">
                                </a>
                                <a href="#" class="btn font-size-12 btn-techanic-business active">Techanic Business</a>
                            </div>
                        </div>
                        <div class="col-md-2 col-2 text-left pl-0">
                            <a href="#" class="btn btn-primary shadow">
                                <i class="fa fa-search"></i>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <section id="faq" class="faq padding-100">
        <div class="container">
            <div class="row align-items-center">
                <!--align-items-center-->
                <div class="col-md-12 col-12" data-aos="fade-right">
                    <h3 class=" text-center title">Paling Sering Ditanya <br> Client Techanic Business</h3>
                    <div class="space-50"></div>
                    <div class="accordion" id="faqAccordion">
                        <div class="card shadow">
                            <div class="card-header" id="heading_1">
                                <h5 class="mb-0">
                                    <button class="btn btn-link" type="button" data-toggle="collapse"
                                        data-target="#collapse_1" aria-expanded="true" aria-controls="collapse_1">
                                        Bagaimana cara mendaftar akun ke Techanic Business ?
                                    </button>
                                </h5>
                            </div>

                            <div id="collapse_1" class="collapse show" aria-labelledby="heading_1"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Pastikan sudah mendownload aplikasi <b>Techanic Business</b> dari app store ataupun play store <br>
                                            2. Buka aplikasinya dan masukkan nomor hp anda, lalu klik lanjut <br>
                                            3. Lalu masukkan kode otp yang yang telah dikirim di nomor whatsapp <br>
                                            4. Lanjutkan pendaftaran dengan mengisi form identitas <br>
                                            5. Buat PIN baru <br>
                                            6. Konfirmasi PIN baru <br>
                                            <b>Selamat, anda telah berhasil mendaftar di Techanic Business</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow">
                            <div class="card-header" id="heading_2">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_2" aria-expanded="false" aria-controls="collapse_2">
                                        Data apa saja yang perlu diisi di setting awal?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_2" class="collapse" aria-labelledby="heading_2"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Siapkan Logo usaha di galeri hp / identitas untuk foto profil usaha <br>
                                            2. Masukkan nama usaha <br>
                                            3. Email usaha <br>
                                            4. Kategori usaha <br>
                                            5. Deskripsi usaha <br>
                                            6. Pada bagian cabang adalah informasi toko usaha anda berjalan <br>
                                            7. Isi nama lokasi cabang <br>
                                            8. Alamat , bisa gunakan map <br>
                                            9. Nomor whatsapp <br>
                                            10. Nomor kantor <br>
                                            11. Upload foto lokasi usaha/toko (gambar terlalu besar) <br>
                                            12. Lalu klik simpan <br>

                                            Akan muncul popup, <b>“Apakah anda ingin menambah cabang lainnya ?”</b> <br>
                                            Jika anda memiliki lebih dari 1 cabang, maka tekan <b>Ya</b> <br>

                                            <b>Selamat, anda berhasil mendaftarkan usaha di techanic business.</b>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow">
                            <div class="card-header" id="heading_3">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_3" aria-expanded="false" aria-controls="collapse_3">
                                        Bagaimana Cara Menambahkan Cabang Usaha ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_3" class="collapse" aria-labelledby="heading_3"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Masuk di App, di halaman Home, pilih setting <br>
                                            2. Pilih Usaha, lalu muncul menu, pilih list Cabang <br>
                                            3. Klik tombol + di kanan bawah <br>
                                            4. Isi data nama / lokasi cabang <br>
                                            5. Masukkan alamat <br>
                                            6. Isi nomor whatsapp <br>
                                            7. Isi nomor kantor <br>
                                            8. Jika anda aktifkan, maka usaha anda akan tampil di web my techanic <br>
                                            9. Upload foto cabang <br>
                                            10. Lalu klik Simpan <br>

                                            <b>Baik cabang usaha berhasil disimpan</b>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="card shadow">
                            <div class="card-header" id="heading_4">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_4" aria-expanded="false" aria-controls="collapse_4">
                                        Bagaimana cara melihat performa karyawan ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_4" class="collapse" aria-labelledby="heading_4"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        <div class="card shadow">
                            <div class="card-header" id="heading_5">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_5" aria-expanded="false" aria-controls="collapse_5">
                                        Bagaimana cara membuat transaksi ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_5" class="collapse" aria-labelledby="heading_5"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Anda harus masuk sebagai teknisi, caranya yaitu:
                                            <ul>
                                                <li>Buka app, masukkan PIN, </li>
                                                <li>Ketika pilih tipe akun, pilih sebagai Teknisi/Pegawai</li>
                                                <li>Anda telah masuk di home Teknisi</li>
                                            </ul>

                                        2. Jika anda sudah login sebagai Pemilik usaha, anda bisa pindah tipe akun dengan cara yaitu:<br>
                                        <ul>
                                            <li>Klik pindah ke teknisi</li>
                                            <li>Muncul popup, pilih usaha anda</li>
                                            <li>Lalu pastikan cabang anda sudah benar, klik Menuju halaman teknisi</li>
                                            <li>Anda telah masuk di home Teknisi</li>
                                        </ul>

                                        3. Di bagian menu bawah, pilih Service<br>
                                        4. Klik + untuk menambah service baru<br>
                                        5. Pilih pelanggan anda, jika tidak ada, anda bisa menambah sebagai pelanggan baru<br>
                                        <ul>
                                            <li>Masukkan nomor hp pelanggan pada kolom pencarian (cth: 81234)</li>
                                            <li>Klik tambah nomor tersebut</li>
                                            <li>Jika nomor tersebut adalah pelanggan baru, maka akan muncul Tambah pelanggan baru</li>
                                            <li>Pastikan nomor hp telah sesuai, lalu isi nama pelanggan anda</li>
                                            <li>Klik tambah</li>
                                        </ul>
                                        6. Pilih device, anda akan diarahkan ke halaman browse device<br>
                                        <ul>
                                            <li>Jika list device tidak tersedia, pilih Manual</li>
                                            <li>Isi nama device</li>
                                            <li>Kategori device</li>
                                            <li>Pilih merk, jika tidak tersedia, pilih lainnya</li>
                                            <li>Pilihan checklist QC bersifat opsional</li>
                                            <li>Lalu klik tambah </li>
                                        </ul>

                                        7. Masukkan Serial Number device tersebut, jika tidak terlihat bisa diubah dengan nomor identitas lainnya <br>
                                        8. Pilih kapasitas, jika tidak tersedia, pilih lainnya <br>
                                        9. Pilih Warna, jika tidak tersedia, pilih -<br>
                                        10. Pilih prioritas kerusakan<br>
                                        11. Berikan keterangan tambahan<br>
                                        12. Pilih kondisi device tersebut saat ini<br>
                                        13. Apakah barang tersebut dititipkan kepada anda?<br>
                                        14. Jika sudah, klik Simpan data service
                                        <br><br>
                                        Anda akan berada di halaman Summary Service, anda bisa scroll ke bagian bawah untuk mengisi detail selanjutnya.<br>
                                        <br>
                                        15. Tambah daftar kendala device tersebut, jika tidak tersedia, klik tambah manual.
                                        <ul>
                                            <li>
                                                Isi nama kerusakan 
                                            </li>
                                            <li>
                                                Klik simpan
                                            </li>
                                            <li>
                                                Jika sudah, klik kembali
                                            </li>
                                        </ul>
                                        16. Tambah Jasa service, jika tidak tersedia, klik Tambah service manual
                                        <ul>
                                            <li>Isi nama jasa service anda</li>
                                            <li>Isi biaya jasa anda</li>
                                            <li>Jika sudah, klik simpan</li>
                                        </ul>
                                        17. Tambah Spare Part, jika tidak tersedia, klik Tambah spare part manual
                                            <ul>
                                                <li>Isi nama sparepart</li>
                                                <li>Pilih warna yang tersedia</li>
                                                <li>Masukkan jumlah kuantitas sparepart yang dibutuhkan</li>
                                                <li>Jika sudah, klik Simpan</li>
                                            </ul> 
                                        18. Tambah uang muka (DP) apabila diperlukan. Untuk menambah uang muka:
                                        <ul>
                                            <li>Klik tambah item</li>
                                            <li>Terdapat 5 pilihan metode bayar (transfer, EDC, E-wallet, Tunai, QRIS)</li>
                                            <li>Pilih salah satu metode, contoh: Tunai</li>
                                            <li>Masukkan nominal</li>
                                            <li>Klik masukkan</li>
                                            <li>Jika sudah, klik Proses</li>
                                        </ul>
                                        
                                        19. Ketika semua data yang dibutuhkan terisi, klik Mulai Bekerja
                                        Konfirmasi, Ya mulai bekerja<br>

                                        <br><b>Anda siap mengerjakan perbaikan device!</b><br><br>

                                        20. Ketika device sudah selesai diperbaiki, masuk ke Summary Service, Lalu klik Selesai Bekerja<br>
                                        21. Klik Buat Invoice<br>
                                        22. Jika anda memberi garansi, pilih Ya, dan masukkan masa garansi yang berlaku<br>
                                        Jika tidak, Pilih tidak<br>
                                        Jika sudah, klik Lihat Invoice<br>
                                        23. Untuk pembayaran pelanggan, klik Bayar<br>
                                        <ul>
                                            <li>Di halaman Rincian pembayaran, Terdapat 5 pilihan metode bayar (transfer, EDC, E-wallet, Tunai, QRIS)</li>
                                            <li>Pilih salah satu metode, contoh: Tunai</li>
                                            <li>Masukkan nominal untuk pelunasan</li>
                                            <li>Klik masukkan</li>
                                            <li>Jika sudah, klik Proses</li>
                                        </ul>   
                                        24. Pembayaran invoice telah selesai, klik Selesai <br>
                                            <b>Selamat, anda telah menyelesaikan 1 transaksi di Techanic Business.</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow">
                            <div class="card-header" id="heading_6">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_6" aria-expanded="false" aria-controls="collapse_6">
                                        Bagaimana cara export laporan kedalam excel ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_6" class="collapse" aria-labelledby="heading_6"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Masuk ke App, pilih sebagai Pemilik Usaha
                                            2. Di Bagian menu bawah, pilih Laporan
                                            3. Pilih Service order
                                            4. Dibagian kanan atas, terdapat icon untuk export, klik icon tersebut
                                            5. Muncul popup Simpan ke excel,
                                            <ul>
                                                <li>Pilih periode transaksi yang diinginkan</li>
                                                <li>Pilih kirim melalui email</li>
                                                <li>Klik kirim excel </li>
                                            </ul>
                                            <b>Selamat, anda telah berhasil mengirim laporan excel</b>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow">
                            <div class="card-header" id="heading_10">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_10" aria-expanded="false" aria-controls="collapse_10">
                                        Bagaimana Cara Menambah Metode Pembayaran Untuk Setiap Cabang ? 
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_10" class="collapse" aria-labelledby="heading_10"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                        1. Buka aplikasi techanic business <br>
                                        2. Pada halaman utama bagian navigasi paling bawah, klik icon Setting <br>
                                        3. Klik Akun Bayar <br>
                                        4. Klik tombol berwarna biru dengan icon plus di pojok kanan bawah <br>
                                        5. Terdapat form penyedia layanan, nomor rekening, metode bayar & pilih cabang <br>
                                        6. Pilih penyedia layanan cth:BCA <br>
                                        7. Selanjutnya isi nomor rekening <br>
                                        8. Pilih metode bayar cth QRIS <br>
                                        9. Pilih cabang <br>
                                        10. Terakhir klik simpan  <br>

                                        <b>Baik metode pembayaran berhasil disimpan</b>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="card shadow">
                            <div class="card-header" id="heading_7">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_7" aria-expanded="false" aria-controls="collapse_7">
                                        Apakah pemilik usaha dapat mengambil alih order dari teknisi yang tidak masuk ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_7" class="collapse" aria-labelledby="heading_7"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Pastikan sudah mendownload aplikasi <b>Techanic Business</b> dari app store ataupun play store <br>
                                            2. Buka aplikasinya dan masukkan nomor hp anda, lalu klik lanjut <br>
                                            3. Lalu masukkan kode otp yang yang telah dikirim di nomor whatsapp <br>
                                            4. Lanjutkan pendaftaran dengan mengisi form identitas <br>
                                            5. Buat PIN baru <br>
                                            6. Konfirmasi PIN baru <br>
                                            7. Selamat, anda telah berhasil mendaftar di <b>Techanic Business</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow">
                            <div class="card-header" id="heading_8">
                                <h5 class="mb-0">
                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                        data-target="#collapse_9" aria-expanded="false" aria-controls="collapse_9">
                                        Siapa pemilik data pelanggan yang terdaftar di Techanic Business ?
                                    </button>
                                </h5>
                            </div>
                            <div id="collapse_9" class="collapse" aria-labelledby="heading_8"
                                data-parent="#faqAccordion">
                                <div class="card-body row">
                                    <div class="col-md-4">
                                        <div class="watch-video faq">
                                            <div class="video">
                                                <img src="assets/img/mobile.png" class="d-none-mobile img-fluid mx-auto" alt="">
                                                <img src="assets/img/mobile-landscape.png" class=" d-none-pc img-fluid mx-auto" alt="">
                                                <a href="https://www.youtube.com/watch?v=2PtGxaaCApg" data-lity></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8" style="align-self: center;">
                                        <p>
                                            1. Pastikan sudah mendownload aplikasi <b>Techanic Business</b> dari app store ataupun play store <br>
                                            2. Buka aplikasinya dan masukkan nomor hp anda, lalu klik lanjut <br>
                                            3. Lalu masukkan kode otp yang yang telah dikirim di nomor whatsapp <br>
                                            4. Lanjutkan pendaftaran dengan mengisi form identitas <br>
                                            5. Buat PIN baru <br>
                                            6. Konfirmasi PIN baru <br>
                                            7. Selamat, anda telah berhasil mendaftar di <b>Techanic Business</b>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>