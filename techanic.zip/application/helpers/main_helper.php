<?php defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('formatted_date')) {
    function formatted_date($timestamp, $format = "d/m/Y - H:i"){
        return date($format, strtotime($timestamp));
    }
}

if (!function_exists('wa_link')) {
    function wa_link(){
        return "https://web.whatsapp.com/send?phone=+6281233236569&text=Hallo%20Techanic,%20saya%20ingin%20menanyakan%20perihal%20Techanic%20Business";
    }
}

if (!function_exists('formatted_date_indo')) {
    function formatted_date_indo($date){
    	$date = formatted_date($date,"Y-m-d");
		$month = array (
			1 =>   
			'Januari',
			'Februari',
			'Maret',
			'April',
			'Mei',
			'Juni',
			'Juli',
			'Agustus',
			'September',
			'Oktober',
			'November',
			'Desember'
		);

		$array = explode('-', $date);
		return $array[2] . ' ' . $month[ (int)$array[1] ] . ' ' . $array[0];
	}
}

if (!function_exists('clean_str')) {
    function clean_str($str)
    {
        $ci =& get_instance();
        $str = $ci->security->xss_clean($str);
        $str = remove_special_characters($str, false);
        return $str;
    }
}

if (!function_exists('remove_special_characters')) {
    function remove_special_characters($str, $is_slug = false)
    {

        $str = trim($str);

        $str = str_replace('#', '', $str);

        $str = str_replace(';', '', $str);

        $str = str_replace('!', '', $str);

        $str = str_replace('"', '', $str);

        $str = str_replace('$', '', $str);

        $str = str_replace('%', '', $str);

        $str = str_replace('(', '', $str);

        $str = str_replace(')', '', $str);

        $str = str_replace('*', '', $str);

        $str = str_replace('+', '', $str);

        $str = str_replace('/', '', $str);

        $str = str_replace('\'', '', $str);

        $str = str_replace('<', '', $str);

        $str = str_replace('>', '', $str);

        $str = str_replace('=', '', $str);

        $str = str_replace('?', '', $str);

        $str = str_replace('[', '', $str);

        $str = str_replace(']', '', $str);

        $str = str_replace('\\', '', $str);

        $str = str_replace('^', '', $str);

        $str = str_replace('`', '', $str);

        $str = str_replace('{', '', $str);

        $str = str_replace('}', '', $str);

        $str = str_replace('|', '', $str);

        $str = str_replace('~', '', $str);

        if ($is_slug == true) {

            $str = str_replace(" ", '-', $str);

            $str = str_replace("'", '', $str);

        }

        return $str;
    }
}

if (!function_exists('trans')) {
    function trans($str)
    {

        
    }
}

if (!function_exists('link_ext')) {
    function link_ext($type='web')
    {

        if($type == 'playstore'){
            return 'https://play.google.com/store/apps/details?id=com.techanic.business.techanic_business&hl=id';
        }

        if($type == 'web'){
            return 'https://www.mytechanic.com/';
        }

        if($type == 'appstore'){
            return 'https://apps.apple.com/id/app/techanic-business/id1633443038';
        }
        
    }
}
