<div class="modal fade" id="showInformation" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body p-0 potition-relative">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <img src="assets/img/popup-new.png" class="img-fluid">
      </div>
    </div>
  </div>
</div>